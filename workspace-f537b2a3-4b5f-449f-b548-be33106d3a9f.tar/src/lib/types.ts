// Shared TypeScript types for the Agent System

export interface Agent {
  id: string;
  name: string;
  type: string; // coordinator, executor, monitor, analyzer, communicator
  status: string; // idle, running, paused, error, offline
  description: string;
  config: string; // JSON string
  avatar: string;
  capabilities: string; // JSON string
  createdAt: string;
  updatedAt: string;
  tasks?: Task[];
  messages?: Message[];
  workflows?: WorkflowAgent[];
  _count?: {
    tasks: number;
    messages: number;
  };
}

export interface Task {
  id: string;
  title: string;
  description: string;
  status: string; // pending, running, completed, failed, cancelled
  priority: string; // low, medium, high, critical
  agentId: string | null;
  workflowId: string | null;
  input: string; // JSON string
  output: string; // JSON string
  error: string | null;
  progress: number; // 0-100
  parentTaskId: string | null;
  depth: number;
  reasoningStep: string; // JSON string
  createdAt: string;
  updatedAt: string;
  completedAt: string | null;
  agent?: Pick<Agent, 'id' | 'name' | 'avatar'> | null;
  workflow?: Pick<Workflow, 'id' | 'name'> | null;
}

export interface Workflow {
  id: string;
  name: string;
  description: string;
  status: string; // draft, active, running, paused, completed, failed
  steps: string; // JSON string
  createdAt: string;
  updatedAt: string;
  agents?: WorkflowAgent[];
  tasks?: Pick<Task, 'id' | 'title' | 'status'>[];
  _count?: {
    tasks: number;
    agents: number;
  };
}

export interface WorkflowAgent {
  id: string;
  workflowId: string;
  agentId: string;
  role: string; // leader, participant, reviewer
  step: number;
  agent?: Pick<Agent, 'id' | 'name' | 'avatar' | 'status'>;
  workflow?: Pick<Workflow, 'id' | 'name'>;
}

export interface Message {
  id: string;
  fromAgentId: string | null;
  toAgentId: string | null;
  type: string; // info, command, result, error, broadcast
  content: string;
  metadata: string; // JSON string
  createdAt: string;
  fromAgent?: Pick<Agent, 'id' | 'name' | 'avatar'> | null;
}

export interface SystemMetric {
  id: string;
  name: string;
  value: number;
  unit: string;
  category: string; // system, agent, task, workflow
  createdAt: string;
}

export interface MetricsSummary {
  agents: {
    total: number;
    running: number;
    idle: number;
    error: number;
    offline: number;
  };
  tasks: {
    total: number;
    pending: number;
    running: number;
    completed: number;
    failed: number;
  };
  workflows: {
    total: number;
    active: number;
    draft: number;
  };
  metrics: SystemMetric[];
}

export interface WorkflowStep {
  id: number;
  name: string;
  agentType: string;
  action: string;
  next: number | null;
}

export interface CollaborationLog {
  id: string;
  sessionId: string;
  phase: string;
  fromAgentId: string | null;
  toAgentId: string | null;
  action: string;
  reasoning: string;
  result: string;
  chainDepth: number;
  createdAt: string;
  fromAgent?: Agent | null;
  toAgent?: Agent | null;
}

export interface CollaborationSession {
  sessionId: string;
  logCount: number;
  lastActivity: string | null;
  phases: string[];
  logs: CollaborationLog[];
}

export interface ReasoningChain {
  rootTask: Task;
  subTasks: Task[];
  chainProgress: number;
  chainType: string;
}

export type ViewType = 'overview' | 'dashboard' | 'agents' | 'tasks' | 'workflows' | 'messages' | 'settings';
