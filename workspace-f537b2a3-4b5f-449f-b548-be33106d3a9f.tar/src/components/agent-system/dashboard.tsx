'use client';

import { useEffect, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Bot,
  Play,
  ListTodo,
  TrendingUp,
  Activity,
  AlertTriangle,
  Zap,
  RefreshCw,
} from 'lucide-react';
import type { Agent, Task, Message, MetricsSummary, SystemMetric } from '@/lib/types';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from 'recharts';

interface DashboardProps {
  agents: Agent[];
  tasks: Task[];
  messages: Message[];
  metrics: MetricsSummary | null;
  loading: boolean;
  onSeed: () => void;
  onRefresh: () => void;
}

const statusColors: Record<string, string> = {
  running: 'bg-emerald-500',
  idle: 'bg-yellow-500',
  error: 'bg-red-500',
  offline: 'bg-gray-400',
  paused: 'bg-orange-500',
};

const statusLabels: Record<string, string> = {
  running: '运行中',
  idle: '空闲',
  error: '错误',
  offline: '离线',
  paused: '暂停',
};

const typeColors: Record<string, string> = {
  coordinator: 'bg-purple-100 text-purple-700',
  executor: 'bg-emerald-100 text-emerald-700',
  monitor: 'bg-amber-100 text-amber-700',
  analyzer: 'bg-cyan-100 text-cyan-700',
  communicator: 'bg-rose-100 text-rose-700',
};

const typeLabels: Record<string, string> = {
  coordinator: '协调器',
  executor: '执行器',
  monitor: '监控器',
  analyzer: '分析器',
  communicator: '通信器',
};

const messageTypeColors: Record<string, string> = {
  command: 'bg-blue-100 text-blue-700',
  result: 'bg-emerald-100 text-emerald-700',
  error: 'bg-red-100 text-red-700',
  broadcast: 'bg-orange-100 text-orange-700',
  info: 'bg-gray-100 text-gray-700',
};

const messageTypeLabels: Record<string, string> = {
  command: '命令',
  result: '结果',
  error: '错误',
  broadcast: '广播',
  info: '信息',
};

export default function Dashboard({
  agents,
  tasks,
  messages,
  metrics,
  loading,
  onSeed,
  onRefresh,
}: DashboardProps) {
  // Compute stats
  const totalAgents = agents.length;
  const runningAgents = agents.filter((a) => a.status === 'running').length;
  const activeTasks = tasks.filter((t) => t.status === 'running').length;
  const completedTasks = tasks.filter((t) => t.status === 'completed').length;
  const totalTasks = tasks.length;
  const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  // Compute chart data from metrics
  const chartData = useMemo(() => {
    if (!metrics?.metrics) return [];
    const throughputMetrics = metrics.metrics.filter(
      (m: SystemMetric) => m.name === 'task_throughput'
    );
    // Group by hour
    const grouped: Record<string, number> = {};
    throughputMetrics.forEach((m: SystemMetric) => {
      const hour = new Date(m.createdAt).getHours();
      const label = `${hour.toString().padStart(2, '0')}:00`;
      grouped[label] = (grouped[label] || 0) + m.value;
    });
    return Object.entries(grouped)
      .map(([name, value]) => ({ name, value: Math.round(value) }))
      .slice(-12);
  }, [metrics]);

  const recentMessages = messages.slice(0, 8);

  return (
    <div className="space-y-6">
      {/* Top Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-l-4 border-l-emerald-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Agent总数</p>
                <p className="text-3xl font-bold">{totalAgents}</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-emerald-100 flex items-center justify-center">
                <Bot className="h-6 w-6 text-emerald-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-teal-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">运行中</p>
                <p className="text-3xl font-bold">{runningAgents}</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-teal-100 flex items-center justify-center">
                <Play className="h-6 w-6 text-teal-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-amber-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">活跃任务</p>
                <p className="text-3xl font-bold">{activeTasks}</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-amber-100 flex items-center justify-center">
                <ListTodo className="h-6 w-6 text-amber-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-cyan-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">完成率</p>
                <p className="text-3xl font-bold">{completionRate}%</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-cyan-100 flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-cyan-600" />
              </div>
            </div>
            <Progress value={completionRate} className="mt-2 h-1.5" />
          </CardContent>
        </Card>
      </div>

      {/* Action Buttons */}
      <div className="flex gap-3">
        <Button
          onClick={onSeed}
          variant="outline"
          className="gap-2 border-emerald-300 text-emerald-700 hover:bg-emerald-50"
        >
          <Zap className="h-4 w-4" />
          初始化数据
        </Button>
        <Button
          onClick={onRefresh}
          variant="outline"
          className="gap-2"
        >
          <RefreshCw className="h-4 w-4" />
          刷新数据
        </Button>
      </div>

      {loading && !agents.length ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Card key={i}>
              <CardContent className="p-4">
                <Skeleton className="h-20 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Agent Status Grid */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Activity className="h-5 w-5 text-emerald-500" />
                  Agent状态
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {agents.map((agent) => (
                    <div
                      key={agent.id}
                      className="flex items-center gap-3 p-3 rounded-lg border bg-card hover:shadow-md transition-shadow"
                    >
                      <div className="text-2xl flex-shrink-0">{agent.avatar || '🤖'}</div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-sm truncate">{agent.name}</span>
                          <span
                            className={`inline-flex h-2.5 w-2.5 rounded-full flex-shrink-0 ${
                              statusColors[agent.status] || 'bg-gray-400'
                            } ${agent.status === 'running' ? 'animate-pulse' : ''}`}
                          />
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge
                            variant="secondary"
                            className={`text-[10px] px-1.5 py-0 ${
                              typeColors[agent.type] || 'bg-gray-100 text-gray-700'
                            }`}
                          >
                            {typeLabels[agent.type] || agent.type}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {statusLabels[agent.status] || agent.status}
                          </span>
                          {agent._count && (
                            <span className="text-xs text-muted-foreground">
                              {agent._count.tasks}个任务
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Real-time Activity Feed */}
          <div>
            <Card className="h-full">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <AlertTriangle className="h-5 w-5 text-amber-500" />
                  实时动态
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[340px]">
                  <div className="space-y-3">
                    {recentMessages.map((msg) => (
                      <div
                        key={msg.id}
                        className="flex gap-2 p-2 rounded-lg bg-muted/50 text-sm"
                      >
                        <span className="text-lg flex-shrink-0">
                          {msg.fromAgent?.avatar || '📡'}
                        </span>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5 mb-0.5">
                            <span className="font-medium text-xs truncate">
                              {msg.fromAgent?.name || '系统'}
                            </span>
                            <Badge
                              variant="secondary"
                              className={`text-[9px] px-1 py-0 ${
                                messageTypeColors[msg.type] || messageTypeColors.info
                              }`}
                            >
                              {messageTypeLabels[msg.type] || msg.type}
                            </Badge>
                          </div>
                          <p className="text-xs text-muted-foreground line-clamp-2">
                            {msg.content}
                          </p>
                          <p className="text-[10px] text-muted-foreground/60 mt-0.5">
                            {new Date(msg.createdAt).toLocaleTimeString('zh-CN')}
                          </p>
                        </div>
                      </div>
                    ))}
                    {recentMessages.length === 0 && (
                      <p className="text-sm text-muted-foreground text-center py-8">
                        暂无消息
                      </p>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* System Metrics Chart */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-lg">
            <TrendingUp className="h-5 w-5 text-cyan-500" />
            任务吞吐量趋势
          </CardTitle>
        </CardHeader>
        <CardContent>
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={chartData} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip
                  contentStyle={{
                    borderRadius: '8px',
                    border: '1px solid #e5e7eb',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
                  }}
                />
                <Bar dataKey="value" fill="#10b981" radius={[4, 4, 0, 0]} name="任务数/小时" />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[260px] flex items-center justify-center text-muted-foreground">
              <p className="text-sm">暂无指标数据，请先初始化数据</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
