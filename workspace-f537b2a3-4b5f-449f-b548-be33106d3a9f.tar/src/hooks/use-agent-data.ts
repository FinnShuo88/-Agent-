'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import type { Agent, Task, Workflow, Message, MetricsSummary } from '@/lib/types';

interface UseAgentDataOptions {
  refreshInterval?: number; // in milliseconds
  enablePolling?: boolean;
}

export function useAgentData(options: UseAgentDataOptions = {}) {
  const { refreshInterval = 10000, enablePolling = true } = options;

  const [agents, setAgents] = useState<Agent[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [metrics, setMetrics] = useState<MetricsSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isSeeded, setIsSeeded] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const fetchAgents = useCallback(async () => {
    try {
      const res = await fetch('/api/agents');
      if (!res.ok) throw new Error('Failed to fetch agents');
      const data = await res.json();
      setAgents(data);
      return data;
    } catch (err) {
      setError(String(err));
      return [];
    }
  }, []);

  const fetchTasks = useCallback(async () => {
    try {
      const res = await fetch('/api/tasks');
      if (!res.ok) throw new Error('Failed to fetch tasks');
      const data = await res.json();
      setTasks(data);
      return data;
    } catch (err) {
      setError(String(err));
      return [];
    }
  }, []);

  const fetchWorkflows = useCallback(async () => {
    try {
      const res = await fetch('/api/workflows');
      if (!res.ok) throw new Error('Failed to fetch workflows');
      const data = await res.json();
      setWorkflows(data);
      return data;
    } catch (err) {
      setError(String(err));
      return [];
    }
  }, []);

  const fetchMessages = useCallback(async () => {
    try {
      const res = await fetch('/api/messages?limit=50');
      if (!res.ok) throw new Error('Failed to fetch messages');
      const data = await res.json();
      setMessages(data);
      return data;
    } catch (err) {
      setError(String(err));
      return [];
    }
  }, []);

  const fetchMetrics = useCallback(async () => {
    try {
      const res = await fetch('/api/metrics');
      if (!res.ok) throw new Error('Failed to fetch metrics');
      const data = await res.json();
      setMetrics(data);
      return data;
    } catch (err) {
      setError(String(err));
      return null;
    }
  }, []);

  const seedData = useCallback(async () => {
    try {
      const res = await fetch('/api/seed', { method: 'POST' });
      if (!res.ok) throw new Error('Failed to seed data');
      const data = await res.json();
      setIsSeeded(true);
      return data;
    } catch (err) {
      setError(String(err));
      return null;
    }
  }, []);

  const refreshAll = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const agentData = await fetchAgents();
      // Auto-seed if no agents exist
      if (agentData.length === 0 && !isSeeded) {
        await seedData();
        await Promise.all([
          fetchAgents(),
          fetchTasks(),
          fetchWorkflows(),
          fetchMessages(),
          fetchMetrics(),
        ]);
      } else {
        await Promise.all([
          fetchTasks(),
          fetchWorkflows(),
          fetchMessages(),
          fetchMetrics(),
        ]);
      }
    } catch (err) {
      setError(String(err));
    } finally {
      setLoading(false);
    }
  }, [fetchAgents, fetchTasks, fetchWorkflows, fetchMessages, fetchMetrics, seedData, isSeeded]);

  // Initial load
  useEffect(() => {
    refreshAll();
  }, [refreshAll]);

  // Polling
  useEffect(() => {
    if (!enablePolling) {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
      return;
    }

    intervalRef.current = setInterval(() => {
      Promise.all([
        fetchAgents(),
        fetchTasks(),
        fetchWorkflows(),
        fetchMessages(),
        fetchMetrics(),
      ]);
    }, refreshInterval);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [enablePolling, refreshInterval, fetchAgents, fetchTasks, fetchWorkflows, fetchMessages, fetchMetrics]);

  return {
    agents,
    tasks,
    workflows,
    messages,
    metrics,
    loading,
    error,
    refreshAll,
    fetchAgents,
    fetchTasks,
    fetchWorkflows,
    fetchMessages,
    fetchMetrics,
    seedData,
    setAgents,
    setTasks,
    setWorkflows,
    setMessages,
    setMetrics,
  };
}
